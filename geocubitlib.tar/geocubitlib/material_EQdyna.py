from __future__ import print_function

try:
    import start as start
    cubit = start.start_cubit()
except:
    try:
        import cubit
    except:
        print('error importing cubit, check if cubit is installed')
        pass
import numpy as np

class assign_material:
    def __init__(self,id,filename,vol_list):
       self.vol_list=vol_list
       self.filename=filename
       self.id=id
       #get layer number (newly generated), vp,vs,rho,depth for material id, in material_param
       depth_list,vp_list,vs_list,rho_list=material_file_read(id,filename)
       #match elelment# with id, layer number in mesh_material,and output into file: material_file
       material_assign(id,vol_list,depth_list)
       #output a new file: filename_$id that provides id,layer number, and vp,vs,rho,depth
       material_file_write(id,filename,vp_list,vs_list,rho_list,depth_list)

def material_file_read(id,filename):
    depth_list=[]
    vp_list=[]
    vs_list=[]
    rho_list=[]
    file=open(filename,'r')
    #how many materials in the model
    num_material=file.readline()
    #how many layers in each materail
    num_layer_txt=file.readline()
    num_layer_list=list(map(int, num_layer_txt.split()))
    #cumulative layers list 
    cumsum_layer_list=list(np.cumsum(num_layer_list))
    cumsum_layer_list.insert(0,0)
    if id>len(num_layer_list) or id<1:
        print('Error! Material id exceeds the maximum/mininum number')
    num_layer=num_layer_list[id-1]
    #materail starting/ending line in filename
    layer_start=2+id+int(cumsum_layer_list[id-1])
    layer_end=layer_start + num_layer
    for i in range(0,layer_start-2):
        tmp=file.readline()
    
    depth_ini=0.
    for i in range(layer_start,layer_end):
        txt=file.readline()
        print(txt)
        thickness,vp,vs,rho=map(float, txt.split())
        depth_list.append(-thickness+depth_ini)
        vp_list.append(vp)
        vs_list.append(vs)
        rho_list.append(rho)
        depth_ini=-thickness+depth_ini
    file.close()
    return depth_list,vp_list,vs_list,rho_list

def material_assign(id,vol_list,depth_list):
    #get all hexes in the vol_list
    hex_list=set([])
    for vol in vol_list:
       hex_tmp=set(cubit.get_volume_hexes(vol))
       hex_list=hex_list.union(hex_tmp)
    hex_list=list(hex_list)

    #output file 
    file_out=open('MESH/material_file','a')
    for ihex in range(0,len(hex_list)):
        x,y,z=cubit.get_center_point('hex',hex_list[ihex])
        ilay=search_depth(z,depth_list)
        txt=str(id)+' '+str(ilay+1)+' '+str(hex_list[ihex])+'\n'
        file_out.write(txt)
    file_out.close()

def material_file_write(id,filename,vp_list,vs_list,rho_list,depth_list):
    file_name_new='MESH/'+filename+'_ref'
    file_out=open(file_name_new,'a')
    for ilay in range(0,len(depth_list)):
        txt=str(id)+' '+str(ilay+1)+' '+str(vp_list[ilay])+' '+str(vs_list[ilay])+' '+str(rho_list[ilay])+\
        ' '+str(depth_list[ilay])+'\n'
        file_out.write(txt)
    file_out.close()
  
def search_depth(depth,depth_list):
    nstart=0
    nend=len(depth_list)-1
    nmid=int((nstart+nend)/2)
    while nstart<nend:
       if depth_list[nmid]>depth:
          nstart=nmid+1
          nmid=int((nstart+nend)/2)
       if depth_list[nmid]<=depth:
          nend=nmid
          nmid=int((nstart+nend)/2)
    return nmid
   
