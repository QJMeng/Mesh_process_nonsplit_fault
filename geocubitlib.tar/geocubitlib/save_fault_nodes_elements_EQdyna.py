#!python
# (same with:save_fault_nodes_elements_EQdyna_bk2.py; completed, nodes on edges of fault will be spli    tted only when the edges are located on boundary of the model box) 
# Input : non-split surface list, volume to the left and right of fault.
#
from __future__ import print_function

#import cubit
import sys
try:
    import start as start
    cubit = start.start_cubit()
except:
    try:
        import cubit
    except:
        print("error importing cubit, check if cubit is installed")
        pass

class fault_input:
    #list_vol1 is list of volumes to the left of surface and list_vol2 is list of volumes to the right
    def __init__(self,id,list_surface,list_vol1,list_vol2):
        self.id = id
        self.list_surface = list_surface
        self.name = 'MESH/fault_file_'+str(id)+'.dat'
        #save_cracks:get quad element number on fault
        quads_net_list = save_cracks(self.name,self.list_surface)
        #Unpacking list.
        dic_quads_all_list = unpack_list(quads_net_list,self.list_surface)

        print('len(quads):',len(dic_quads_all_list))

        save_elements_nodes(self.name,dic_quads_all_list,list_vol1,list_vol2,list_surface)

def save_cracks(name,list_surface):
    quads_net_list = []
    for surface in list_surface   :
        #get a list of the number of quad element (a hex element is composed by 6 quads)
        quads_single_list = list(cubit.get_surface_quads(surface))
        quads_net_list.append(quads_single_list)
    # TO DO : stop python properly in case fault nodes at both sides
    #         do not match.
    #   if len(quads_fault_u) != len(quads_fault_d): stop
    #
    # SAVING FAULT ELEMENTS AND NODES
    return quads_net_list

def unpack_list(quads_net_list,list_surface):
    dic_quads_all_list = {}
    for i in range(0,len(quads_net_list)):
        surface=list_surface[i]
        el = list(quads_net_list[i])
        for j in el:
            dic_quads_all_list[j]=surface
    return dic_quads_all_list

def save_elements_nodes(name,dic_quads_all_list,list_vol1,list_vol2,list_surface):
    print('')
    print('## save fault nodes elements: file = ',name)
    print('##')
    fault_file = open(name,'w')
    txt = ''
    #get a list of number of hex element in vol1 list
    volumes1='in vol'
    volumes2='in vol'
    for i in list_vol1:
        volumes1 = volumes1 + ' ' + str(i)
    for j in list_vol2:
        volumes2 = volumes2 + ' ' + str(j)
    #get all hex elements in vol1 list and vol2 list
    list_hex_vol1 = cubit.parse_cubit_list('hex',volumes1)
    list_hex_vol2 = cubit.parse_cubit_list('hex',volumes2)
    #all nodes
    node_list = cubit.parse_cubit_list('node', 'all')
    num_MAX = max(node_list)
        #construct another dictionary 
        #key: slave node#, value: slave hex element#, area,normal direction,master node#, master hex element# 
    dic_nodes = {}
    #cubit.cmd('set info off')
    #cubit.cmd('set echo off')
#check node and elment in volume vol1
    for h in list_hex_vol1:
        #get_sub_elements: Get the lower dimesion entities associated with a higher dimension entities,h(hex element #),2-> dimension of the desired lower dimension
        faces = cubit.get_sub_elements('hex',h,2)
        for f in faces:
            if f in dic_quads_all_list.keys():
               # get surface# quad f belongs to
                surface=dic_quads_all_list[f]
                nodes=cubit.get_connectivity('quad',f)
#silent_cmd:Pass a command string into Cubit and have it executed without being verbose at the command prompt.
                #calculate quad area
                if not len(nodes)==4:
                        print('Node number in a quad is not 4')
                        sys.exit('goodbye')
                else: 
                        x1,y1,z1=cubit.get_nodal_coordinates(nodes[0])
                        x2,y2,z2=cubit.get_nodal_coordinates(nodes[1])
                        x3,y3,z3=cubit.get_nodal_coordinates(nodes[2])
                        x4,y4,z4=cubit.get_nodal_coordinates(nodes[3])
                        a1=( (x2-x1)**2 + (y2-y1)**2 + (z2-z1)**2 ) ** 0.5
                        b1=( (x3-x2)**2 + (y3-y2)**2 + (z3-z2)**2 ) ** 0.5
                        c1=( (x4-x3)**2 + (y4-y3)**2 + (z4-z3)**2 ) ** 0.5
                        d1=( (x1-x4)**2 + (y1-y4)**2 + (z1-z4)**2 ) ** 0.5 
                        p1=( (x4-x2)**2 + (y4-y2)**2 + (z4-z2)**2 ) ** 0.5
                        q1=( (x3-x1)**2 + (y3-y1)**2 + (z3-z1)**2 ) ** 0.5
                        area=0.25 * (4.0*p1*p1*q1*q1 - (b1*b1 + d1*d1 - a1*a1 -c1*c1)**2)**0.5
                #put nodes in dictonary
                for node in nodes:
                        if node not in dic_nodes.keys():
                            dic_nodes[node]=[]
                            #dic_nodes[node].append(h)
                            dic_nodes[node].append(area)
                            x, y, z = cubit.get_nodal_coordinates(node)
                            v1,v2,v3=cubit.get_surface_normal_at_coord(surface,[x,y,z])
                            dic_nodes[node].append([v1,v2,v3])
                        else:
                            #dic_nodes[node][1]+=area
                            dic_nodes[node][0]+=area

 #check node and element in volume vol2
    for h in list_hex_vol2:
        #get all nodes belonging to hex h
        # cubit.silent_cmd('group "nf" add Node in hex '+str(h))
        # group1 = cubit.get_id_from_name("nf")
        # nodes_h = []
         nodes_h=cubit.get_connectivity('hex',h)
         #if not group1 == []:
         #      nodes_h = cubit.get_group_nodes(group1)
         #      cubit.silent_cmd('del group '+ str(group1))

         for node_h in nodes_h:
             if node_h in dic_nodes.keys():
                   #if len(dic_nodes[node_h])==3:
                   if len(dic_nodes[node_h])==2:
                   #master node is slave node + Max (number > max node#)
                       dic_nodes[node_h].append(node_h+num_MAX) #master node#
                       dic_nodes[node_h].append([])  #master hex# list
                       #dic_nodes[node_h][4].append(h)
                       dic_nodes[node_h][3].append(h)
                   #elif len(dic_nodes[node_h])==5:
                   #   dic_nodes[node_h][4].append(h)
                   elif len(dic_nodes[node_h])==4:
                       dic_nodes[node_h][3].append(h)
                   else:
                       print('slave node infomation error')
                       sys.exit('goodbye')
                #debug
                #print('#fault down nodes: ',nodes,len(nodes),group1)

        #debug
        #nodes=cubit.get_connectivity('Face',f)
        #print('h,fault nodes side down :',h,nodes[0],nodes[1],nodes[2],nodes[3])

    #get fault non-split boundary nodes 
    nonsplit_nodes=define_nonsplit_nodes(list(dic_nodes),list_surface)
    print('Number of nonsplit nodes:',len(nonsplit_nodes))

    dic_nonsplit_nodes=dict(zip(nonsplit_nodes,nonsplit_nodes)) 
    # number of slave nodes
    txt = '%10i\n' % (len(dic_nodes)-len(dic_nonsplit_nodes))
    fault_file.write(txt)
    print('Number of split nodes:',len(dic_nodes)-len(dic_nonsplit_nodes))
    #output the node infomation out 
    for key in dic_nodes:
        if not key in dic_nonsplit_nodes.keys():
            info=dic_nodes[key]
            #slave node#,area,vector x,y,z,master node#
            #txt= '%10i %10.2f %10.5f %10.5f %10.5f %10i ' % (key,info[0],info[1],\
            #     info[2][0],info[2][1],info[2][2],info[3])
            txt= '%10i %10.2f %10.5f %10.5f %10.5f %10i ' % (key,info[0],\
                  info[1][0],info[1][1],info[1][2],info[2])
            fault_file.write(txt)
            #number of element with master node
            #ele_num=len(info[4])
            ele_num=len(info[3])
            txt='%10i ' % (ele_num)
            for k in range(0,ele_num):
                #txt+= '%10i ' % info[4][k]
                txt+= '%10i ' % info[3][k]
            txt+='\n'
            fault_file.write(txt)

    fault_file.close()

    #cubit.cmd('set info on')
    #cubit.cmd('set echo on')

    print('## done fault file: ',name)
    print('')


def define_model_boundary():
    list_vol = cubit.parse_cubit_list("volume", "all")

    # min/max of bounding box
    xmin = cubit.get_total_bounding_box("volume", list_vol)[0]                                                   
    xmax = cubit.get_total_bounding_box("volume", list_vol)[1]
    ymin = cubit.get_total_bounding_box("volume", list_vol)[3]
    ymax = cubit.get_total_bounding_box("volume", list_vol)[4]
    zmin = cubit.get_total_bounding_box("volume", list_vol)[6]
    zmax = cubit.get_total_bounding_box("volume", list_vol)[7]
    return xmin,xmax,ymin,ymax,zmin,zmax

#get the fault surface boundary boxes, where nodes should not be splitted 
def define_nonsplit_nodes(nodes_all_list,surface_list,tol=0.5):
    overlap_curve_set=set([])
    join_curve_set=set([])
    for i in range(0,len(surface_list)):
        surface1=surface_list[i]
        curves1=cubit.get_relatives('surface',surface1,'curve')
        join_curve_set=set(curves1).union(join_curve_set)
        for j in range(i+1,len(surface_list)):
             surface2=surface_list[j]
             curves2=cubit.get_relatives('surface',surface2,'curve')
             inter_curve_set=set(curves1).intersection(set(curves2))
             overlap_curve_set=overlap_curve_set.union(inter_curve_set)
    #exclude the curves on intersection of two surfaces, only remain the outer most boundary curves: non_overlap_curve_list
    print('Joint curves:',join_curve_set)
    print('Overlap curves:',overlap_curve_set)
    nonoverlap_curve_set=join_curve_set.difference(overlap_curve_set)
    #get inside vertex of the fault plane
    inside_vertex=set([])
    for curve1 in nonoverlap_curve_set:
        for curve2 in  overlap_curve_set:
            common_vertex=cubit.get_common_vertex_id(curve1,curve2)
            if common_vertex>0:
                inside_vertex.add(common_vertex)
    #get all vertex of the whole fault plane
    all_vertex=set([])
    join_curve_list=list(join_curve_set)
    if(len(join_curve_list)>1):
        for i in range(0,len(join_curve_list)-1):
            curve1=join_curve_list[i]
            for j in  range(i+1,len(join_curve_list)):
                curve2=join_curve_list[j]
                common_vertex=cubit.get_common_vertex_id(curve1,curve2)
                #print('curve1,curve2',curve1,curve2)
                if common_vertex>0:
                    # print('common vertex',common_vertex)
                     all_vertex.add(common_vertex)
                     #print(all_vertex)
    #get outside vertex (four points) of the whole fault plane
    outside_vertex=all_vertex.difference(inside_vertex)
                 
    #get nodes inside four outside boudary curves
    interior_nodes=set([])
    #get nodes on overlap curves (excluding vertexs)
    for curve in overlap_curve_set:
        interior_nodes=interior_nodes.union(set(cubit.get_curve_nodes(curve)))    
    #get nodes each surface (excluding bounary curves and vertexs)
    for surface in surface_list:
        interior_nodes=interior_nodes.union(set(cubit.get_surface_nodes(surface)))
    #get all split nodes (including all interior nodes)
    split_nodes=interior_nodes
    #get model boundary coordinates
    xmin,xmax,ymin,ymax,zmin,zmax=define_model_boundary()

    #judge nodes on outside curves (should split or not)
    for curve in nonoverlap_curve_set:
        nodes=cubit.get_curve_nodes(curve)
        for node in nodes:
           x,y,z=cubit.get_nodal_coordinates(node)
           #if curve locates on boundaries, then node on curves should be splitted, thus removed from curve list
           if abs(x-xmin)<tol or abs(x-xmax)<tol or abs(y-ymin)<tol or  abs(y-ymax)<tol or abs(z-zmin)<tol or abs(z-zmax)<tol :
               split_nodes.add(node)
    #judge nodes on vertex (should split or not)
    for vertex in inside_vertex:
        node=cubit.get_vertex_node(vertex)
        x,y,z=cubit.get_nodal_coordinates(node)
        if abs(x-xmin)<tol or abs(x-xmax)<tol or abs(y-ymin)<tol or  abs(y-ymax)<tol or abs(z-zmin)<tol or abs(z-zmax)<tol :
            split_nodes.add(node)
    #for the outside vertex, is must located at intersection of two boudaries, it should be splitted, otherwise nonsplit
    for vertex in outside_vertex:
        node=cubit.get_vertex_node(vertex)
        x,y,z=cubit.get_nodal_coordinates(node)
        if (abs(x-xmin)<tol or abs(x-xmax)<tol or abs(y-ymin)<tol or  abs(y-ymax)<tol) and (abs(z-zmin)<tol or abs(z-zmax)<tol) :
             split_nodes.add(node)
    nonsplit_nodes_list=list(set(nodes_all_list).difference(split_nodes))
    return nonsplit_nodes_list

